Marla Singer on the CivFanatics Colonization Forum
http://forums.civfanatics.com/archive/index.php/f-29.html 
</H3>
Hello everyone,

Recently I've played again to Colonization. For the little story, it's the first real video game I played to outside 
minesweeper. 

Anyway, I've decided to create a map for my own pleasure, but I thought maybe some of you would like it too. It's a map of
North America, from the St Lawrence river and the great Lakes in the North to the Yucatan peninsula and the Great Carribeans
(Cuba, Jamaica, Hispaniola, Puerto Rico) in the South.

I've also edited the Tribe file and the Names file in order to play with American Natives accurately located. The new 
Natives are :

- Algonquins (replacing Apaches)
- Chipewas (replacing Sioux)
- Seminoles (replacing Tupis)
- Mayas (replacing Incas)

Iroquois, Cherokees, Arawaks and Aztecs are still there... except that Aztecs are now located in Louisiana (sorry I didn't
know what to do with them).

Ok, here are the instructions to play with it :
- Create a new folder and call it original files
- Cut and paste in that folder the following files : names.txt, tribe.txt, woodcut.txt, amer2.mp
- Copy the zip files into the Colonization folder (c:/mps/colonize).

Those files are actually new names.txt, tribe.txt, woodcut.txt and amer2.mp. If I've given you the following instructions,
it is to avoid you to lose the original documents. If you know better solutions, please tell me.

Thank you to give your advice about it. 
